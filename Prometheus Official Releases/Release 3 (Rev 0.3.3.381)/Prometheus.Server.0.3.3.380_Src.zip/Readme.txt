This is the source code for the release
The source code has error reporting on, while the release does not.

-Tsusai